from django.urls import path
from . import views 
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('', views.router, name='router'),
    path('Skill/', views.skill, name="skill"),
    path('skills_for_reader/', views.skills_for_reader, name='skills_for_reader'),
    path('articles/<int:id>', views.articles, name='articles'),
    path('chapter/<int:id>', views.chapter, name="chapter"),
    path('chapterformanage/', views.chapterformanage, name="chapter_for_manage"),
    path('articles_in_chapter/', views.articles_in_chapter, name="articles_in_chapter"),
    path('Attendence/<int:id>', views.attendence, name='attendence'),
    path('Learning_Path/<int:id>', views.learning_path, name='learning_path'),
    path('Skills/', views.skills, name="skills"),
    path('SkillsForPath/', views.skills_for_path, name="skills_for_path"),
    path('chapter_in_path/', views.chapter_in_path, name="chapter_in_path"),
    path('registration_page/', views.registration_page, name='registration_page'),
    path('login_page/', views.login_page, name="login_page"),
    path('logout/', views.logout, name="logout"),
    path('reader/', views.reader, name="reader"),
    path('editblog/<int:chapter_id>', views.editblog, name="editblog"),
    path('writer/', views.writer, name="writer"),
    path('create_article/', views.create_article, name="create_article"),
    path('program_manager/', views.program_manager, name="program_manager"),
    path('articlesdetail/<int:id>', views.articlesdetail, name="articlesdetail"),
    path('add_coins_to_reader/<int:id>', views.add_coins_to_reader, name="add_coins_to_reader"),
    path('add_learning_path/', views.add_learning_path, name="add_learning_path"),
    path('add_chapter/', views.add_chapter, name="add_chapter"),
    path('writer_login/', views.writer_login, name="writer_login"),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)




