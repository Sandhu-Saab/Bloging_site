from django.contrib import admin
from .models import Articles, Readers, Skill, Chapter, Writers, Learning_Path, ChapterInPath
from .models import UserInstance, ArticlesInChapter, SkillsForReader, SkillsForPath, Attendence
# Register your models here.


class AttendenceAdmin(admin.ModelAdmin):
    list_display = ('id', 'start_learning', 'end_learning', 'reader', 'article')
admin.site.register(Attendence, AttendenceAdmin)

class UserInstanceAdmin(admin.ModelAdmin):
    list_display = ('id', 'username')
admin.site.register(UserInstance, UserInstanceAdmin)

class ReaderAdmin(admin.ModelAdmin):
    list_display = ('reader', 'coins')
admin.site.register(Readers, ReaderAdmin)

class Learning_PathAdmin(admin.ModelAdmin):
    list_display = ('learning_path_name',)
admin.site.register(Learning_Path, Learning_PathAdmin)



class ChapterAdmin(admin.ModelAdmin):
    list_display = ('id','chapter_title')
admin.site.register(Chapter, ChapterAdmin)


class ArticlesInChapterAdmin(admin.ModelAdmin):
    list_display = ('id','all_Articles', 'chapter')
admin.site.register(ArticlesInChapter, ArticlesInChapterAdmin)


class WritersAdmin(admin.ModelAdmin):
    list_display = ('user_instance', 'coins')
admin.site.register(Writers, WritersAdmin)

class ArticlesAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'writer')
admin.site.register(Articles, ArticlesAdmin)


class SkillAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')
admin.site.register(Skill, SkillAdmin)

class SkillsForReaderAdmin(admin.ModelAdmin):
    list_display = ('id', 'skill', 'reader')
admin.site.register(SkillsForReader, SkillsForReaderAdmin)

class SkillsForPathAdmin(admin.ModelAdmin):
    list_display = ('id', 'skills', 'learning_path')
admin.site.register(SkillsForPath, SkillsForPathAdmin)

class ChapterInPathAdmin(admin.ModelAdmin):
    list_display = ('id', 'Chapter', 'learning_path')
admin.site.register(ChapterInPath, ChapterInPathAdmin)