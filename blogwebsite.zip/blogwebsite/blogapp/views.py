
from dataclasses import dataclass
import datetime
from unittest import result
from .models import *
from django.shortcuts import get_object_or_404, render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import auth, Group
from django.urls import reverse
from django.contrib.auth import logout as logouts
from django.views.decorators.csrf import csrf_exempt
from django.core.paginator import Paginator

import math




# Create your views here.



def router(request):
    if request.user.is_authenticated:

        if request.user.groups.filter(name='ProgramManager').exists():
            return redirect('program_manager')


        if request.user.groups.filter(name='writer').exists():
            return redirect('writer')


        if request.user.groups.filter(name='reader').exists():
            return redirect('reader')


    else:
           return redirect('login_page')
      

def reader(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='reader').exists():
            path = Skill.objects.all()
            result = {"skill": path}
        return render(request,'reader.html', result)
    else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)

def learning_path(request, id):
    if request.user.is_authenticated:
                if request.user.groups.filter(name='reader').exists():
                    path = SkillsForPath.objects.filter(skills=id)
                    print(path)
                    result = {"skillforpath": path}
                    return render(request,'LearningPath.html', result)
                else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)

def chapter(request, id):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='reader').exists():
            chapter_path = ChapterInPath.objects.filter(Chapter=id)
            result = {'chapter_path':chapter_path} 

            return render(request,'chapter.html', result)
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)

def articles(request, id):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='reader').exists():
            chapter_path = ArticlesInChapter.objects.filter(chapter=id)
            
            
            result = {'chapter_path':chapter_path}


            return render(request,'articles.html', result) 
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)


def articlesdetail(request, id):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='reader').exists():
            if request.method == 'POST':
                print(request.POST)
                print(request)
                
                article = request.POST.get('article')
                user = Attendence(reader=request.user.readers, article_id=article)
                
                user.save()
                t1 = datetime.datetime.now()
                print("sdknfkgnk", t1)

                chapter_path = Articles.objects.filter(id=id)

                end_learning_time = Attendence.objects.filter(id=id)

                reader_data = Readers.objects.filter(id=id).order_by("id")[0:1]

            
                next_article = Articles.objects.filter(id__gt=id).order_by("id")[0:1]
                prev_article = Articles.objects.filter(id__lt=id).order_by("id")[0:1]
                
                result = {'articles1':chapter_path, 'end_learning_time': end_learning_time, 'next_article': next_article,'prev_article':prev_article, 'reader_data':reader_data }
                t2 = datetime.datetime.now()
                print("total time on artical", t2-t1)
                return render(request,'articlesdetail.html', result)
                
            else:
                print('helo')
                chapter_path = Articles.objects.filter(id=id)
                result = {'articles':chapter_path} 
                
                return render(request,'articlesdetail.html', result)
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)


def add_coins_to_reader(request, id):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='reader').exists():
                reader_info = Readers.objects.filter(id=id)
                skill_info = Skill.objects.filter(id=id)
                result = {'reader_info':reader_info, 'skill_info':skill_info}

                reader_object = Readers.objects.get(id=id)
                reader_object.coins += 50
                # reader_object.skills += str(Python)
                

                reader_object.save()
 
                return render(request, "add_coins_to_reader.html", result)

        else:
                html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                return HttpResponse(html)


def create_article(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='writer').exists():
            if request.method == 'POST':
                    title = request.POST.get('title')
                    body = request.POST.get('body')
                    coins = request.POST.get('coins')
                    obj = Articles(title=title, body=body, coins=coins, writer=request.user.writers)
                    obj.save()

                    profile = obj.writer
                    profile.coins += 20
                    profile.save()
                    blogdata =  Articles.objects.filter(writer= request.user.writers)
                    result = {"all_blogdata": blogdata}
                    return render(request, 'create_article.html', result)

            else:
                return render(request, 'create_article.html')
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)


def attendence(request, id):
    if request.user.is_authenticated:    
        if request.user.groups.filter(name='reader').exists():
            date_time = Attendence.objects.filter(id=id)
            result = {'date_time':date_time}
            if request.method == 'POST':
                print(request.POST)
                article = request.POST.get('article')
                end_learning = request.POST.get('end_learning')

                date_time.article = article
                date_time.end_learning = end_learning
                date_time.save()

                # obj = Attendence(reader=request.user.readers, article_id=article, end_learning=end_learning)
                # obj.save()
                
                
            return render(request,'attendence.html', result)
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)



# def editblog(request, blog_id):
#     if request.user.is_authenticated:
#         blogid = Blog.objects.get(id=blog_id)
#         result = {"x": blogid}
#         if request.method == 'POST':
#                 print(request.POST)
#                 title = request.POST.get('title')
#                 body = request.POST.get('body')
#                 status_draft = request.POST.get('status_draft')
#                 status_publish = request.POST.get('status_publish')
#                 if status_draft == 'on':
#                     status_draft = True
#                 else:
#                     status_draft = False
#                 if status_publish == 'on':
#                     status_publish = True
#                 else:
#                     status_publish = False

                # blogid.title = title
                # blogid.body = body
#                 blogid.status_draft = status_draft
#                 blogid.status_publish = status_publish
#                 blogid.save()
#                 context = {'blogdetail':blogid}
#                 # return render(request, 'editblog.html', context)
#                 blogdata =  Blog.objects.filter(author_instance= request.user.authorinstance)
#                 result = {"all_blogdata": blogdata}
#                 return render(request, 'author_page.html', result)
#         else:
#             return render(request, 'editblog.html', result)
#     else:
#            return redirect('login_page')

    
def writer(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='writer').exists():

            blogdata =  Articles.objects.filter(writer= request.user.writers)
            result = {"all_blogdata": blogdata}
            return render(request, 'writer.html', result)
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)

def writer_login(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='reader').exists():
            group = Group.objects.get(name="writer")
            request.user.groups.add(group)
            blogdata =  Articles.objects.filter(writer= request.user.writers)
            result = {"all_blogdata": blogdata}
            return render(request, 'writer.html', result)
        else:
                html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                return HttpResponse(html)

def program_manager(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='ProgramManager').exists():
    
            return render(request,'ProgramManager.html')
        
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)

def skill(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='ProgramManager').exists():
            if request.method == 'POST':
                name = request.POST['name']
                skills = Skill(name=name)
                skills.save()

            return render(request,'skill.html')
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)

def chapterformanage(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='ProgramManager').exists():

            chapter_data = Chapter.objects.all()
            result = {"chapter_data": chapter_data}

            return render(request, 'chapterformanage.html', result)
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)

def articles_in_chapter(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='ProgramManager').exists():
            if request.method == 'POST':
                
                articles = request.POST.get('all_Articles')
                chapter = request.POST.get('chapter')

                data = ArticlesInChapter(all_Articles_id=articles, chapter_id=chapter)
                print(data)
                data.save()

            article_data =  Articles.objects.all()
            
            chapter_data = Chapter.objects.all()
        
            df={'article':article_data, 'chapter':chapter_data}
            return render(request, 'articles_in_chapter.html', df)
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)

def chapter_in_path(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='ProgramManager').exists():
            if request.method == 'POST':
                    learning_path = request.POST.get('learning_path')
                    chapter = request.POST.get('chapter')

                    data = ChapterInPath(learning_path_id=learning_path, Chapter_id=chapter)
                    data.save()
            blogdata =  Chapter.objects.all()
            
            pathid = Learning_Path.objects.all()
            
            df={'chapter':blogdata, 'learning':pathid}
            return render(request,'chapter_in_path.html', df)
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)
     

def add_learning_path(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='ProgramManager').exists():
            if request.method == 'POST':
                learning_path = request.POST.get('learning_path_name')

                data = Learning_Path(learning_path_name=learning_path)
                data.save()

            return render(request, 'add_learning_path.html')
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)


def add_chapter(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='ProgramManager').exists():
            if request.method == 'POST':
                chapter_title = request.POST.get('chapter_title')
                coins = request.POST.get('coins')

                data = Chapter(chapter_title=chapter_title, coins=coins)
                data.save()

            return render(request, 'add_chapter.html')
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)


def skills(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='ProgramManager').exists():
            if request.method == 'POST':
                name = request.POST.get('name')

                data = Skill(name=name)
                data.save()
            return render(request,'skill.html')
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)


def skills_for_path(request):
    if request.user.is_authenticated:
        if request.user.groups.all().exists():
            if request.method == 'POST':
                    skills = request.POST.get('skills')
                    learning_path = request.POST.get('learning_path')

                    data = SkillsForPath(skills_id=skills, learning_path_id=learning_path)
                    data.save()


            skills =  Skill.objects.all()

            learning_path = Learning_Path.objects.all()
            df= {'skills':skills, 'learning_path': learning_path}

            return render(request,'skills_for_path.html', df)
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)


def skills_for_reader(request):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='ProgramManager').exists():
            if request.method == 'POST':
                skill = request.POST.get('skill')
                reader = request.POST.get('reader')

                data = SkillsForReader(skill_id=skill, reader_id=reader)
                data.save()


            skills =  Skill.objects.all()

            readerdata = Readers.objects.all()
            df= {'skills':skills, 'readerdata': readerdata}


            return render(request,'skills_for_reader.html', df)
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)   


def registration_page(request):
    if request.user.is_authenticated:
        return redirect('router')
    else:
        if request.method == 'POST':
                username = request.POST.get('username')
                email = request.POST.get('email')
                password = request.POST.get('password')

                user = UserInstance.objects.create_user(username=username, email=email, password=password)
                user.save()

                group = Group.objects.get(name='reader')
                user.groups.add(group)

                print('User Created')

                return redirect('router')
        else:
            return render(request,'registration_page.html')

def login_page(request):
    if request.user.is_authenticated:
        print("hello")
        return redirect('router')
        

    else:
        print("hello else")
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = auth.authenticate(username=username, password=password)
            if user is not None:
                auth.login(request, user)

                return redirect('router')
            else:
                return HttpResponse("Invalid username or password")
        else:
            return render(request, 'login_page.html')

def logout(request):
    if request.user.is_authenticated:
        
            logouts(request)
            return redirect('router')
        
    else:
        return redirect('router')


def editblog(request, chapter_id):
    if request.user.is_authenticated:
        if request.user.groups.filter(name='writer').exists():
            chapter_data = Chapter.objects.get(id=chapter_id)
            result = {"x": chapter_data}
            if request.method == 'POST':
                    print(request.POST)
                    coins = request.POST.get('coins')

                    chapter_data.coins = coins
                    chapter_data.save()

                    return redirect('chapter_for_manage')
            else:
                return render(request, 'editblog.html', result)
        else:
                    html = '<!DOCTYPE html><html><head></head><body><h1> Unauthorized Access </h1></body></html>'
                    return HttpResponse(html)


