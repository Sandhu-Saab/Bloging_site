from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.


class UserInstance(AbstractUser):
    mobile = models.CharField(max_length=10)

    def __str__(self):
        return str(self.username)

class Skill(models.Model):
    name = models.CharField(max_length=50, null=True)

def __str__(self):
        return str(self.name)

class Writers(models.Model):
    user_instance = models.OneToOneField(UserInstance, on_delete=models.PROTECT)
    coins = models.IntegerField(default=100)


class Readers(models.Model):
    reader = models.OneToOneField(UserInstance, on_delete=models.CASCADE)
    coins = models.IntegerField(blank=True, null=True)

    def __str__(self):
        return str(self.reader)

    
class SkillsForReader(models.Model):
    skill = models.ForeignKey(Skill, on_delete=models.PROTECT)
    reader = models.ForeignKey(Readers, on_delete=models.PROTECT)

class Articles(models.Model):
    title = models.CharField(max_length=500)
    body = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)
    writer = models.ForeignKey(Writers, on_delete=models.PROTECT)
    coins = models.IntegerField(blank=True)

    def __str__(self):
        return str(self.title)


class ProgramManager(models.Model):
    program_user = models.ForeignKey(UserInstance, on_delete=models.CASCADE)



class Chapter(models.Model):
    chapter_title = models.CharField(max_length=50)
    coins = models.IntegerField()
    
    def __str__(self):
        return str(self.chapter_title)


class ArticlesInChapter(models.Model):
    all_Articles = models.ForeignKey(Articles, on_delete=models.PROTECT)
    chapter = models.ForeignKey(Chapter, on_delete=models.PROTECT)


class Attendence(models.Model):
    start_learning = models.DateTimeField(auto_now_add=True)
    end_learning = models.DateTimeField(blank=True, null=True)
    reader = models.ForeignKey(Readers, on_delete=models.CASCADE)
    article = models.ForeignKey(Articles, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.reader)

class Learning_Path(models.Model):
    learning_path_name = models.CharField(max_length=80)

    def __str__(self):
        return str(self.learning_path_name)


class SkillsForPath(models.Model):
    skills = models.ForeignKey(Skill, on_delete=models.PROTECT)
    learning_path = models.ForeignKey(Learning_Path, on_delete=models.PROTECT)


class ChapterInPath(models.Model):
    Chapter = models.ForeignKey(Chapter, on_delete=models.PROTECT)
    learning_path = models.ForeignKey(Learning_Path, on_delete=models.PROTECT)  